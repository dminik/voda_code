using Orchard.ContentManagement;

namespace Orchard.Comments.Models {
    public class CommentPart : ContentPart<CommentPartRecord> {
    }
}