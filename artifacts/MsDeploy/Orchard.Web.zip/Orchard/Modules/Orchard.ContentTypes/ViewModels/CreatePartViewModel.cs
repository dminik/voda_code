﻿namespace Orchard.ContentTypes.ViewModels {
    public class CreatePartViewModel {
        public string Name { get; set; }
    }
}
