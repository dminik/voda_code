﻿namespace Orchard.ContentTypes.ViewModels {
    public class ContentTypeSettingsViewModel {
        public bool Creatable { get; set; }
        public bool Draftable{ get; set; }
        public string Stereotype { get; set; }
    }
}