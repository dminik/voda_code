﻿namespace Orchard.ContentTypes.ViewModels {
    public class CreateTypeViewModel  {
        public string DisplayName { get; set; }
        public string Name { get; set; }
    }
}
